package com.example.geeksasaeng.Config.Secret

object Secret {
    // 네이버 KEY
    var OAUTH_CLIENT_ID: String = "Kvyd6swFfWHQJgjWaHr1"
    var OAUTH_CLIENT_SECRET = "pq8VgJC5sn"
    var OAUTH_CLIENT_NAME = "긱사생"
}